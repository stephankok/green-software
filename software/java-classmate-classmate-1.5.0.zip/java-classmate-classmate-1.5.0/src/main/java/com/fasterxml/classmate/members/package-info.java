/**
 * Package that contains implementations of various member types
 * (methods, fields, constructors)
 */
package com.fasterxml.classmate.members;
