/**
 * Various utility classes used by ClassMate.
 */
package com.fasterxml.classmate.util;
