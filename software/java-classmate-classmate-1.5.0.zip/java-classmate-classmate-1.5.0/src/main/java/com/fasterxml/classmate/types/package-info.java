/**
 * Package that contains {@link com.fasterxml.classmate.ResolvedType}
 * implementation classes.
 */
package com.fasterxml.classmate.types;
