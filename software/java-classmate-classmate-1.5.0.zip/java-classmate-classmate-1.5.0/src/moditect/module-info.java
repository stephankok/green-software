// NOTE: auto-generated with Moditect plugin, on 22-Mar-2019
module com.fasterxml.classmate {
    exports com.fasterxml.classmate;
    exports com.fasterxml.classmate.members;
    exports com.fasterxml.classmate.types;
    exports com.fasterxml.classmate.util;
}
